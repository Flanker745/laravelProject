<x-layout>
<x-slot:heading>
        Contact Page
    </x-slot:heading>
    <h1 class="text-[25px] px-9">Hello From Contact </h1>
</x-layout>