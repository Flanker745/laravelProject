<x-layout>
<x-slot:heading>
        Job listings
    </x-slot:heading>
    <h1 class="text-[25px] px-9">Hello From Jobs </h1>
    <ul>
        <!-- @foreach ($jobs as $job )
                <li>{{ $job }}</li>
        @endforeach -->
        
    </ul>
</x-layout>