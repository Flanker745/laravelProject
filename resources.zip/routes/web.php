<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home' ,[
        'title' => 'Hello',
        'user'=> "Pradeep"
    ]);
});
Route::get('/about', function () {
    return view("about");
});
Route::get('/jobs', function () {
    return view("jobs",[
      "jobs" =>  [
            "title" => "Director",
            "Sallery" => "50,000"
        ],
        [
            "title" => "Programmer",
            "Sallery" => "30,000"
        ],
        [
            "title" => "Staff",
            "Sallery" => "10,000"
        ]
    ]);
});
Route::get('/contact', function () {
    return view("contact");
});
